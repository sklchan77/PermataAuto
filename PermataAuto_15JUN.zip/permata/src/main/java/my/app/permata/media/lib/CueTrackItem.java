package my.app.permata.media.lib;

import android.support.v4.media.MediaMetadataCompat;

import androidx.annotation.NonNull;

import my.app.permata.media.engine.MetadataBuilder;
import my.app.permata.media.lib.MediaLib.BrowsableItem;
import my.app.permata.media.lib.MediaLib.Item;
import my.app.utils.async.FutureSupplier;
import my.app.utils.text.SharedTextBuilder;
import my.app.utils.vfs.VirtualResource;

import static my.app.utils.async.Completed.completedNull;
import static my.app.utils.async.Completed.completedVoid;

/**
 * @author sklchan77
 */
class CueTrackItem extends PlayableItemBase {
	public static final String SCHEME = "cuetrack";
	private final String title;
	private final String performer;
	private final String writer;
	private final String albumTitle;
	private final int trackNumber;
	private final long offset;
	private long duration;
	private final boolean isVideo;

	CueTrackItem(String id, BrowsableItem parent, int trackNumber, VirtualResource file, String title,
							 String performer, String writer, String albumTitle, long offset, boolean isVideo) {
		super(id, parent, file);

		this.title = title;
		this.performer = performer;
		this.writer = writer;
		this.albumTitle = albumTitle;
		this.trackNumber = trackNumber;
		this.offset = offset;
		this.isVideo = isVideo;
	}

	@NonNull
	static FutureSupplier<Item> create(DefaultMediaLib lib, String id) {
		assert id.startsWith(SCHEME);
		int i1 = id.indexOf(':');
		if (i1 == -1) return completedNull();
		int i2 = id.indexOf(':', i1 + 1);
		if (i2 == -1) return completedNull();

		SharedTextBuilder tb = SharedTextBuilder.get();
		tb.append(CueItem.SCHEME).append(id, i2, id.length());

		return lib.getItem(tb.releaseString()).then(i -> {
			CueItem cue = (CueItem) i;
			if (cue == null) return completedNull();

			int n = Integer.parseInt(id.substring(i1 + 1, i2));
			return cue.getTrack(n);
		});
	}

	public int getTrackNumber() {
		return trackNumber;
	}

	@Override
	public boolean isVideo() {
		return isVideo;
	}

	@NonNull
	@Override
	protected FutureSupplier<MediaMetadataCompat> buildMeta(MetadataBuilder meta) {
		meta.putString(MediaMetadataCompat.METADATA_KEY_TITLE, title);
		meta.putLong(MediaMetadataCompat.METADATA_KEY_DURATION, duration);

		if (performer != null) {
			meta.putString(MediaMetadataCompat.METADATA_KEY_ARTIST, performer);
		}
		if (writer != null) {
			meta.putString(MediaMetadataCompat.METADATA_KEY_WRITER, writer);
		}
		if (albumTitle != null) {
			meta.putString(MediaMetadataCompat.METADATA_KEY_ALBUM, albumTitle);
		}

		return super.buildMeta(meta);
	}

	@Override
	public long getOffset() {
		return offset;
	}

	void duration(long duration) {
		this.duration = duration;
	}

	@NonNull
	@Override
	public FutureSupplier<Void> setDuration(long duration) {
		return completedVoid();
	}

	@Override
	public boolean isTimerRequired() {
		return true;
	}

	@Override
	public String getOrigId() {
		String id = getId();
		if (id.startsWith(SCHEME)) return id;
		return id.substring(id.indexOf(SCHEME));
	}
}
