package my.app.permata.media.sub;

import static my.app.utils.function.Cancellable.CANCELED;

import java.util.ArrayList;

import my.app.permata.media.sub.SubGrid.Position;
import my.app.utils.concurrent.HandlerExecutor;
import my.app.utils.function.BiConsumer;
import my.app.utils.function.Cancellable;
import my.app.utils.function.LongSupplier;

/**
 * @author sklchan77
 */
public class SubScheduler {
	private final HandlerExecutor executor;
	private final SubGrid subtitles;
	private final BiConsumer<Position, Subtitles.Text> consumer;
	private final LongSupplier clock;
	private final ArrayList<Worker> workers;
	private long time;
	private long syncTime;
	private float speed;
	private boolean started;

	public SubScheduler(HandlerExecutor executor, SubGrid subtitles,
											BiConsumer<Position, Subtitles.Text> consumer) {
		this(executor, subtitles, consumer, System::currentTimeMillis);
	}

	public SubScheduler(HandlerExecutor executor, SubGrid subtitles,
											BiConsumer<Position, Subtitles.Text> consumer, LongSupplier clock) {
		this.executor = executor;
		this.subtitles = subtitles;
		this.consumer = consumer;
		this.clock = clock;
		workers = new ArrayList<>(9);
		for (var e : subtitles) {
			var s = e.getValue();
			if (s instanceof Subtitles.Stream || !s.isEmpty()) {
				workers.add(new Worker(e.getKey(), e.getValue()));
			}
		}
		workers.trimToSize();
	}

	public SubGrid getSubtitles() {
		return subtitles;
	}

	public void start(long time, int delay, float speed) {
		if (started) return;
		started = true;
		sync(time, delay, speed);
		assert started;
	}

	public void stop(boolean pause) {
		started = false;
		for (var w : workers) w.stop(pause);
		assert !started;
	}

	public boolean isStarted() {
		return started;
	}

	public void sync(long time, int delay, float speed) {
		assert speed > 0;
		if (!started) return;
		this.time = time + delay;
		this.speed = speed;
		syncTime = clock.getAsLong();
		for (var w : workers) {
			if (!w.isStarted()) w.start();
		}
	}

	private final class Worker implements Runnable {
		private final Position pos;
		private final Subtitles subtitles;
		private Cancellable sched = CANCELED;


		Worker(Position pos, Subtitles subtitles) {
			this.pos = pos;
			this.subtitles = subtitles;
		}

		@Override
		public void run() {
			assert started;
			assert !sched.cancel();
			long time = time();
			Subtitles.Text text = subtitles.getNext(time);

			if (text == null) {
				stop(false);
				return;
			}

			long delay = text.getTime() - time;

			if (delay > 500) {
				consumer.accept(pos, null);
				sched(delay);
			} else {
				consumer.accept(pos, text);
				sched(text.getDuration() + delay);
			}
		}

		void start() {
			assert !sched.cancel();
			sched = executor.submit(this);
		}

		void stop(boolean pause) {
			if (!pause) consumer.accept(pos, null);
			sched.cancel();
			sched = CANCELED;
		}

		boolean isStarted() {
			return sched != CANCELED;
		}

		private long time() {
			return time + (long) (speed * (clock.getAsLong() - syncTime));
		}

		private void sched(long delay) {
			if (!started) return;
			delay /= speed;
			if (delay > 0) sched = executor.schedule(this, delay);
			else sched = CANCELED;
		}
	}
}
