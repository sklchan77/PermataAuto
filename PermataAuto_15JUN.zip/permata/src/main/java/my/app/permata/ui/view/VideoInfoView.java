package my.app.permata.ui.view;

import static my.app.utils.text.TextUtils.isNullOrBlank;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.net.Uri;
import android.support.v4.media.MediaDescriptionCompat;
import android.support.v4.media.MediaMetadataCompat;
import android.util.AttributeSet;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.google.android.material.textview.MaterialTextView;

import my.app.permata.R;
import my.app.permata.media.engine.MediaEngine;
import my.app.permata.media.engine.StreamEngine;
import my.app.permata.media.lib.MediaLib.PlayableItem;
import my.app.permata.media.lib.MediaLib.StreamItem;
import my.app.permata.media.service.PermataServiceUiBinder;
import my.app.permata.ui.activity.MainActivityDelegate;
import my.app.permata.ui.activity.MainActivityListener;
import my.app.permata.util.Utils;
import my.app.utils.async.FutureSupplier;

/**
 * @author sklchan77
 */
public class VideoInfoView extends ConstraintLayout
		implements MainActivityListener, PermataServiceUiBinder.Listener {

	public VideoInfoView(@NonNull Context context, @Nullable AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public VideoInfoView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		inflate(context, R.layout.video_info_layout, this);
		getActivity().onSuccess(a -> {
			a.addBroadcastListener(this, ACTIVITY_DESTROY);
			a.getMediaServiceBinder().addBroadcastListener(this);
			setBackgroundColor(Color.BLACK);
			onPlayableChanged(null, a.getCurrentPlayable());
		});
	}

	@Override
	public void setVisibility(int visibility) {
		if (visibility == VISIBLE) {
			getActivity().onSuccess(a -> {
				MediaEngine eng = a.getMediaServiceBinder().getCurrentEngine();
				if (eng == null) return;
				PlayableItem i = eng.getSource();
				if ((i instanceof StreamItem) && !(eng instanceof StreamEngine)) onPlayableChanged(i, i);
			});
		}

		super.setVisibility(visibility);
	}

	@Override
	public void onActivityEvent(MainActivityDelegate a, long e) {
		if (handleActivityDestroyEvent(a, e)) a.getMediaServiceBinder().removeBroadcastListener(this);
	}

	@Override
	public void onPlayableChanged(PlayableItem oldItem, PlayableItem newItem) {
		if ((newItem == null) || !newItem.isVideo()) {
			setVisibility(GONE);
			return;
		}

		FutureSupplier<MediaDescriptionCompat> getDsc = newItem.getMediaDescription();
		FutureSupplier<MediaMetadataCompat> getMd = newItem.getMediaData();
		setData(newItem, getDsc, getMd);
	}

	public void setData(PlayableItem item, FutureSupplier<MediaDescriptionCompat> getDsc,
											FutureSupplier<MediaMetadataCompat> getMd) {
		if (getDsc.isDone() && !getDsc.isFailed()) {
			setDescription(item, getDsc.getOrThrow());

			if (getMd.isDone() && !getMd.isFailed()) {
				setMetadata(item, getMd.getOrThrow());
			} else {
				getMd.main().onSuccess(md -> getActivity().onSuccess(a -> {
					if (isCurrent(a, item)) setMetadata(item, md);
				}));
			}
		} else {
			getTitleView().setText(item.getName());
			getIconView().setVisibility(GONE);
			getSubtitleView().setVisibility(GONE);
			getSubtitleView().setVisibility(GONE);
			getDescriptionView().setVisibility(GONE);

			getDsc.main().onSuccess(dsc -> getActivity().onSuccess(a -> {
				if (isCurrent(a, item)) {
					setDescription(item, dsc);
					getMd.main().onSuccess(md -> {
						if (isCurrent(a, item)) setMetadata(item, md);
					});
				}
			}));
		}
	}

	public void setDescription(PlayableItem item, MediaDescriptionCompat md) {
		if (md == null) return;
		Uri i = md.getIconUri();
		CharSequence t = md.getTitle();
		CharSequence s = md.getSubtitle();
		CharSequence d = md.getDescription();
		MaterialTextView tv = getTitleView();
		MaterialTextView sv = getSubtitleView();
		MaterialTextView dv = getDescriptionView();
		setIcon(item, i == null ? null : i.toString());
		if (!isNullOrBlank(t)) tv.setText(t);

		if (isNullOrBlank(s)) {
			sv.setVisibility(GONE);
		} else {
			sv.setText(s);
			sv.setVisibility(VISIBLE);
		}
		if (isNullOrBlank(d)) {
			dv.setVisibility(GONE);
		} else {
			dv.setText(d);
			dv.setVisibility(VISIBLE);
		}
	}

	public void setMetadata(PlayableItem item, MediaMetadataCompat md) {
		if (md == null) return;
		String i = md.getString(MediaMetadataCompat.METADATA_KEY_DISPLAY_ICON_URI);
		String s = md.getString(MediaMetadataCompat.METADATA_KEY_DISPLAY_SUBTITLE);
		String d = md.getString(MediaMetadataCompat.METADATA_KEY_DISPLAY_DESCRIPTION);
		MaterialTextView sv = getSubtitleView();
		MaterialTextView dv = getDescriptionView();
		if (i != null) setIcon(item, i);

		if (!isNullOrBlank(s)) {
			sv.setText(s);
			sv.setVisibility(VISIBLE);
		}
		if (!isNullOrBlank(d)) {
			dv.setText(d);
			dv.setVisibility(VISIBLE);
		}
	}

	private void setIcon(PlayableItem item, String icon) {
		if (icon == null) {
			AppCompatImageView iv = getIconView();
			iv.setImageResource(item.getIcon());
			iv.setImageTintList(ColorStateList.valueOf(Utils.getLauncherColor()));
			iv.setVisibility(VISIBLE);
		} else {
			getIconView().setVisibility(GONE);
			item.getLib().getBitmap(icon, true, false).main().onSuccess(b -> {
				if (b == null) return;
				getActivity().onSuccess(a -> {
					if (isCurrent(a, item)) {
						AppCompatImageView iv = getIconView();
						iv.setImageBitmap(b);
						iv.setImageTintList(null);
						iv.setVisibility(VISIBLE);
					}
				});
			});
		}
	}

	private boolean isCurrent(MainActivityDelegate a, PlayableItem i) {
		return (a.getCurrentPlayable() == i);
	}

	private AppCompatImageView getIconView() {
		return findViewById(R.id.media_item_icon);
	}

	private MaterialTextView getTitleView() {
		return findViewById(R.id.media_item_title);
	}

	private MaterialTextView getSubtitleView() {
		return findViewById(R.id.media_item_subtitle);
	}

	private MaterialTextView getDescriptionView() {
		return findViewById(R.id.media_item_dsc);
	}

	private FutureSupplier<MainActivityDelegate> getActivity() {
		return MainActivityDelegate.getActivityDelegate(getContext());
	}
}
